//+build linux

package platforms

import _ "example.com/repo/platforms/linux"
