package testdata

var Data = 42
