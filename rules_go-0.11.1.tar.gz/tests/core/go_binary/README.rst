Basic go_binary functionality
=============================

.. _go_binary: /go/core.rst#_go_binary

Tests to ensure the basic features of go_binary are working as expected.

out_test
--------

Test that a go_binary_ rule can write its executable file with a custom name
in the package directory (not the mode directory).
