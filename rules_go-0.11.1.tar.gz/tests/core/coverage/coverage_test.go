package a

import "testing"

func TestLive(t *testing.T) {
	ALive()
}
