Basic go_library functionality
==============================

.. _go_library: /go/core.rst#_go_library

empty
-----

Checks that a `go_library`_ will compile and link even if all the sources
(including assembly sources) are filtered out by build constraints.
