// +build !linux

const char* cgoC = "unknown";
