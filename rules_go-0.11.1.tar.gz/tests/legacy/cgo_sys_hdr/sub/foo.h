int x = 42;
