package cgo

func PrintCXXVersion() {
	printCXXVersion()
}
