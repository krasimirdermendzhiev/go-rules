package deep

// Thought emulates Deep Thought.
func Thought() int {
	return 42
}
