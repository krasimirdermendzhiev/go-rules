const int foo = 42;
