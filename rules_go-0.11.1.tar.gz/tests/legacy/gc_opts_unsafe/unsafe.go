package main

import "unsafe"

var null = unsafe.Pointer(uintptr(0))
