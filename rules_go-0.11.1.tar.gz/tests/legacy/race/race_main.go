package main

import (
	"github.com/bazelbuild/rules_go/tests/race"
)

func main() {
	race.TriggerRace()
}
