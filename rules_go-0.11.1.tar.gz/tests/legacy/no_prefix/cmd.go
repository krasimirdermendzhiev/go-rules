package main

import _ "github.com/bazelbuild/rules_go/tests/no_prefix"

func main() {
}
