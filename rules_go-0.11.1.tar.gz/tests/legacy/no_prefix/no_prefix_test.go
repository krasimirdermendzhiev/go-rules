package no_prefix_test

import _ "github.com/bazelbuild/rules_go/tests/no_prefix"
