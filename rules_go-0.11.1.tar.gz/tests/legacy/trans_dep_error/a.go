package a

import _ "github.com/bazelbuild/rules_go/tests/trans_dep_error/b"
