package trans_dep_error

import _ "github.com/bazelbuild/rules_go/tests/trans_dep_error/a"
import _ "github.com/bazelbuild/rules_go/tests/trans_dep_error/b"
