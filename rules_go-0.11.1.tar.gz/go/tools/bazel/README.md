# Golang Bazel helper package

This directory contains useful utilities for interacting with Bazel from Go.

Currently the `bazel` package supports:

*   Getting the path for a runfile in a test.

*   Finding and entering the location of the runfiles of a binary.
